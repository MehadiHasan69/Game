"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface GameObject {
  x: number
  y: number
  width: number
  height: number
  vx: number
  vy: number
}

interface Player extends GameObject {
  onGround: boolean
  direction: "left" | "right"
}

interface Enemy extends GameObject {
  direction: "left" | "right"
  alive: boolean
}

interface Coin extends GameObject {
  collected: boolean
}

interface Platform extends GameObject {}

export default function MarioGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const gameLoopRef = useRef<number>()
  const keysRef = useRef<Set<string>>(new Set())

  const [gameState, setGameState] = useState<"menu" | "playing" | "gameOver" | "won">("menu")
  const [score, setScore] = useState(0)
  const [lives, setLives] = useState(3)

  // Game objects
  const playerRef = useRef<Player>({
    x: 50,
    y: 400,
    width: 32,
    height: 32,
    vx: 0,
    vy: 0,
    onGround: false,
    direction: "right",
  })

  const platformsRef = useRef<Platform[]>([
    // Ground platforms
    { x: 0, y: 550, width: 800, height: 50, vx: 0, vy: 0 },
    { x: 900, y: 550, width: 800, height: 50, vx: 0, vy: 0 },
    // Floating platforms
    { x: 200, y: 450, width: 150, height: 20, vx: 0, vy: 0 },
    { x: 400, y: 350, width: 150, height: 20, vx: 0, vy: 0 },
    { x: 600, y: 250, width: 150, height: 20, vx: 0, vy: 0 },
    { x: 800, y: 400, width: 100, height: 20, vx: 0, vy: 0 },
    { x: 1000, y: 300, width: 150, height: 20, vx: 0, vy: 0 },
    { x: 1200, y: 450, width: 150, height: 20, vx: 0, vy: 0 },
    { x: 1400, y: 350, width: 100, height: 20, vx: 0, vy: 0 },
  ])

  const enemiesRef = useRef<Enemy[]>([
    { x: 300, y: 518, width: 24, height: 24, vx: -1, vy: 0, direction: "left", alive: true },
    { x: 500, y: 318, width: 24, height: 24, vx: 1, vy: 0, direction: "right", alive: true },
    { x: 900, y: 518, width: 24, height: 24, vx: -1, vy: 0, direction: "left", alive: true },
    { x: 1100, y: 268, width: 24, height: 24, vx: 1, vy: 0, direction: "right", alive: true },
  ])

  const coinsRef = useRef<Coin[]>([
    { x: 250, y: 400, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 450, y: 300, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 650, y: 200, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 850, y: 350, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 1050, y: 250, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 1250, y: 400, width: 16, height: 16, vx: 0, vy: 0, collected: false },
    { x: 1450, y: 300, width: 16, height: 16, vx: 0, vy: 0, collected: false },
  ])

  const cameraRef = useRef({ x: 0, y: 0 })

  // Collision detection
  const checkCollision = (a: GameObject, b: GameObject): boolean => {
    return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y
  }

  // Game physics and logic
  const updateGame = useCallback(() => {
    if (gameState !== "playing") return

    const player = playerRef.current
    const platforms = platformsRef.current
    const enemies = enemiesRef.current
    const coins = coinsRef.current

    // Handle input
    if (keysRef.current.has("ArrowLeft") || keysRef.current.has("a")) {
      player.vx = -5
      player.direction = "left"
    } else if (keysRef.current.has("ArrowRight") || keysRef.current.has("d")) {
      player.vx = 5
      player.direction = "right"
    } else {
      player.vx *= 0.8 // Friction
    }

    if (
      (keysRef.current.has("Space") || keysRef.current.has("ArrowUp") || keysRef.current.has("w")) &&
      player.onGround
    ) {
      player.vy = -15
      player.onGround = false
    }

    // Apply gravity
    player.vy += 0.8

    // Update player position
    player.x += player.vx
    player.y += player.vy

    // Platform collision
    player.onGround = false
    for (const platform of platforms) {
      if (checkCollision(player, platform)) {
        // Landing on top
        if (player.vy > 0 && player.y < platform.y) {
          player.y = platform.y - player.height
          player.vy = 0
          player.onGround = true
        }
        // Hitting from below
        else if (player.vy < 0 && player.y > platform.y) {
          player.y = platform.y + platform.height
          player.vy = 0
        }
        // Side collision
        else if (player.vx > 0 && player.x < platform.x) {
          player.x = platform.x - player.width
        } else if (player.vx < 0 && player.x > platform.x) {
          player.x = platform.x + platform.width
        }
      }
    }

    // Update enemies
    enemies.forEach((enemy) => {
      if (!enemy.alive) return

      enemy.x += enemy.vx

      // Enemy platform collision and direction change
      let onPlatform = false
      for (const platform of platforms) {
        if (checkCollision(enemy, platform) && enemy.vy >= 0) {
          enemy.y = platform.y - enemy.height
          onPlatform = true
          break
        }
      }

      // Change direction at platform edges or walls
      if (!onPlatform || enemy.x <= 0 || enemy.x >= 1500) {
        enemy.vx *= -1
        enemy.direction = enemy.direction === "left" ? "right" : "left"
      }

      // Enemy-player collision
      if (checkCollision(player, enemy)) {
        // Player jumping on enemy
        if (player.vy > 0 && player.y < enemy.y) {
          enemy.alive = false
          player.vy = -10
          setScore((prev) => prev + 100)
        } else {
          // Player hit by enemy
          setLives((prev) => {
            const newLives = prev - 1
            if (newLives <= 0) {
              setGameState("gameOver")
            }
            return newLives
          })
          // Reset player position
          player.x = 50
          player.y = 400
          player.vx = 0
          player.vy = 0
        }
      }
    })

    // Coin collection
    coins.forEach((coin) => {
      if (!coin.collected && checkCollision(player, coin)) {
        coin.collected = true
        setScore((prev) => prev + 50)
      }
    })

    // Check win condition (collect all coins)
    if (coins.every((coin) => coin.collected)) {
      setGameState("won")
    }

    // Death by falling
    if (player.y > 600) {
      setLives((prev) => {
        const newLives = prev - 1
        if (newLives <= 0) {
          setGameState("gameOver")
        }
        return newLives
      })
      player.x = 50
      player.y = 400
      player.vx = 0
      player.vy = 0
    }

    // Update camera to follow player
    cameraRef.current.x = Math.max(0, Math.min(player.x - 400, 1000))
  }, [gameState])

  // Render game
  const render = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const camera = cameraRef.current

    // Clear canvas
    ctx.fillStyle = "#87CEEB" // Sky blue
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Save context for camera transform
    ctx.save()
    ctx.translate(-camera.x, -camera.y)

    if (gameState === "playing" || gameState === "gameOver" || gameState === "won") {
      // Draw platforms
      ctx.fillStyle = "#8B4513" // Brown
      platformsRef.current.forEach((platform) => {
        ctx.fillRect(platform.x, platform.y, platform.width, platform.height)
      })

      // Draw coins
      ctx.fillStyle = "#FFD700" // Gold
      coinsRef.current.forEach((coin) => {
        if (!coin.collected) {
          ctx.beginPath()
          ctx.arc(coin.x + coin.width / 2, coin.y + coin.height / 2, coin.width / 2, 0, Math.PI * 2)
          ctx.fill()
        }
      })

      // Draw enemies
      ctx.fillStyle = "#FF4500" // Red-orange
      enemiesRef.current.forEach((enemy) => {
        if (enemy.alive) {
          ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height)
          // Simple face
          ctx.fillStyle = "#000"
          ctx.fillRect(enemy.x + 4, enemy.y + 4, 4, 4) // Eyes
          ctx.fillRect(enemy.x + 16, enemy.y + 4, 4, 4)
          ctx.fillStyle = "#FF4500"
        }
      })

      // Draw player
      const player = playerRef.current
      ctx.fillStyle = "#FF0000" // Red (Mario's shirt)
      ctx.fillRect(player.x, player.y, player.width, player.height)

      // Simple Mario face
      ctx.fillStyle = "#FFDBAC" // Skin color
      ctx.fillRect(player.x + 8, player.y + 4, 16, 12)

      // Hat
      ctx.fillStyle = "#FF0000"
      ctx.fillRect(player.x + 4, player.y, 24, 8)

      // Eyes
      ctx.fillStyle = "#000"
      ctx.fillRect(player.x + 10, player.y + 8, 2, 2)
      ctx.fillRect(player.x + 20, player.y + 8, 2, 2)

      // Mustache
      ctx.fillRect(player.x + 12, player.y + 12, 8, 2)
    }

    // Restore context
    ctx.restore()

    // Draw UI
    ctx.fillStyle = "#000"
    ctx.font = "20px Arial"
    ctx.fillText(`Score: ${score}`, 10, 30)
    ctx.fillText(`Lives: ${lives}`, 10, 60)

    if (gameState === "gameOver") {
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.fillStyle = "#FFF"
      ctx.font = "48px Arial"
      ctx.textAlign = "center"
      ctx.fillText("Game Over!", canvas.width / 2, canvas.height / 2)
      ctx.font = "24px Arial"
      ctx.fillText("Press R to restart", canvas.width / 2, canvas.height / 2 + 50)
    }

    if (gameState === "won") {
      ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.fillStyle = "#FFD700"
      ctx.font = "48px Arial"
      ctx.textAlign = "center"
      ctx.fillText("You Won!", canvas.width / 2, canvas.height / 2)
      ctx.font = "24px Arial"
      ctx.fillText("Press R to play again", canvas.width / 2, canvas.height / 2 + 50)
    }

    ctx.textAlign = "left"
  }, [gameState, score, lives])

  // Game loop
  const gameLoop = useCallback(() => {
    updateGame()
    render()
    gameLoopRef.current = requestAnimationFrame(gameLoop)
  }, [updateGame, render])

  // Start game
  const startGame = () => {
    setGameState("playing")
    setScore(0)
    setLives(3)

    // Reset game objects
    playerRef.current = {
      x: 50,
      y: 400,
      width: 32,
      height: 32,
      vx: 0,
      vy: 0,
      onGround: false,
      direction: "right",
    }

    enemiesRef.current.forEach((enemy) => {
      enemy.alive = true
    })

    coinsRef.current.forEach((coin) => {
      coin.collected = false
    })

    cameraRef.current = { x: 0, y: 0 }
  }

  // Event handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current.add(e.code)

      if (e.code === "KeyR" && (gameState === "gameOver" || gameState === "won")) {
        startGame()
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current.delete(e.code)
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [gameState])

  // Start game loop
  useEffect(() => {
    if (gameState === "playing") {
      gameLoopRef.current = requestAnimationFrame(gameLoop)
    }

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current)
      }
    }
  }, [gameState, gameLoop])

  if (gameState === "menu") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-600 flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-bold text-red-600">🍄 Super Mario Game 🍄</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center space-y-2">
              <p className="text-lg">Welcome to the Mario Adventure!</p>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>
                  <strong>Controls:</strong>
                </p>
                <p>← → or A/D: Move</p>
                <p>↑ or W or Space: Jump</p>
                <p>R: Restart (when game over)</p>
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>
                  <strong>Objective:</strong>
                </p>
                <p>Collect all coins and avoid enemies!</p>
                <p>Jump on enemies to defeat them!</p>
              </div>
            </div>
            <Button onClick={startGame} className="w-full bg-red-600 hover:bg-red-700">
              Start Game
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="relative">
        <canvas ref={canvasRef} width={800} height={600} className="border-2 border-gray-600 bg-sky-200" tabIndex={0} />
        <div className="absolute top-2 right-2 text-white text-sm">
          Use arrow keys or WASD to move, Space/W/↑ to jump
        </div>
      </div>
    </div>
  )
}
